# رفيق | RAFEEQ — Android starter project

An Arabic-first, dark Islamic prayer companion for Android. Default city: Tripoli, Libya.

## Included in this first source build
- Arabic RTL Compose interface.
- Offline solar prayer-time calculation for Tripoli (approximate default angles: Fajr 18°, Isha 17.5°).
- Prayer-time list and next-prayer display.
- Local prayer reminders scheduled with Android AlarmManager and restored after device reboot.
- Daily rotating selection from a small set of Quran verses (Arabic text and references included in source).
- Prayer checklist saved locally on the device.
- Arabic text-to-speech response and optional speech recognition through the Android speech service installed on the phone.
- Adhan playback hook: if a licensed audio file named `adhan.mp3` is supplied at `app/src/main/res/raw/adhan.mp3`, the app plays it at prayer time. If no audio file is present, it announces the prayer time using Arabic text-to-speech.

## Important accuracy and audio notes
- Prayer-time calculations are offline estimates, not a certified official Libyan timetable. The default coordinates are central Tripoli and the default Fajr/Isha angles must be checked against the current Libyan Awqaf timetable. Add local minute adjustments before relying on the alarms for daily worship.
- No famous muezzin recording is bundled. Add only an audio recording you have permission to use, named exactly `adhan.mp3`, in `app/src/main/res/raw/`. Then rebuild the app.
- Speech recognition availability and offline Arabic recognition depend on the Android device and installed speech service. Arabic TTS uses the phone's installed Arabic voice where available.
- Android battery optimization, notification permission, and background execution policies vary by manufacturer. Enable notifications and allow RAFEEQ to run in the background for dependable reminders.
- This is an initial functional starter, not a fully verified release. Test prayer times, alarms, audio playback, reboot restoration, and voice recognition on the target phone before relying on it.

## Build APK from a phone using GitHub Actions
1. Create a new empty repository on GitHub using your phone browser or GitHub app.
2. Upload the contents of this project ZIP to the repository (not the ZIP file itself; extract it first if the upload method requires that).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Run **Build RAFEEQ APK** using **Run workflow**, or push to the `main` branch.
5. When the workflow finishes successfully, open its run, scroll to **Artifacts**, and download `RAFEEQ-debug-APK`.
6. Extract the downloaded artifact and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Local build
Requires JDK 17 and Gradle 8.9:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
