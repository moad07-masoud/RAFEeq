package com.rafeeq.app

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.LocalDateTime
import java.time.ZoneId

object PrayerAlarm {
    private const val CHANNEL = "rafeeq_prayer"
    fun scheduleNext(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = LocalDateTime.now(PrayerTimes.zoneId())
        val candidates = (0..1).flatMap { offset ->
            PrayerTimes.today(now.toLocalDate().plusDays(offset.toLong()))
                .filter { it.name != "الشروق" }
                .map { p -> Triple(p, now.toLocalDate().plusDays(offset.toLong()).atTime(p.hour, p.minute), offset) }
        }.filter { it.second.isAfter(now) }.sortedBy { it.second }
        candidates.take(5).forEachIndexed { index, (p, dateTime, _) ->
            val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                putExtra("prayer_name", p.name)
                putExtra("prayer_time", p.time)
            }
            val pi = PendingIntent.getBroadcast(context, 4100 + index, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val at = dateTime.atZone(PrayerTimes.zoneId()).toInstant().toEpochMilli()
            val alarmInfo = AlarmManager.AlarmClockInfo(at, pi)
            alarm.setAlarmClock(alarmInfo, pi)
        }
    }
    fun showPrayerNotification(context: Context, name: String, time: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "تنبيهات الصلاة", NotificationManager.IMPORTANCE_HIGH).apply { description = "تذكيرات دخول أوقات الصلاة" }
        )
        val open = PendingIntent.getActivity(context, 900, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان وقت صلاة $name")
            .setContentText("حيّ على الصلاة — $time | رفيق")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        manager.notify((name + time).hashCode(), notification)
    }
}

class PrayerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("prayer_name") ?: "الصلاة"
        val time = intent.getStringExtra("prayer_time") ?: ""
        PrayerAlarm.showPrayerNotification(context, name, time)
        val play = Intent(context, AdhanPlaybackService::class.java).putExtra("prayer_name", name)
        try { ContextCompat.startForegroundService(context, play) } catch (_: Exception) { }
        PrayerAlarm.scheduleNext(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) PrayerAlarm.scheduleNext(context)
    }
}
