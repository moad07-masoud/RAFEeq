package com.rafeeq.app

import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.*

data class PrayerTime(val name: String, val time: String, val hour: Int, val minute: Int)

/** Offline solar calculation for Tripoli. Default angles are configurable estimates, not a claim of official Libyan authority times. */
object PrayerTimes {
    private const val LAT = 32.8872
    private const val LON = 13.1913
    private val zone: ZoneId = ZoneId.of("Africa/Tripoli")

    fun today(date: LocalDate = LocalDate.now(zone)): List<PrayerTime> {
        val jd = date.toEpochDay().toDouble() + 2440587.5
        val t = (jd - 2451545.0) / 36525.0
        val l0 = norm(280.46646 + t * (36000.76983 + t * 0.0003032))
        val m = 357.52911 + t * (35999.05029 - 0.0001537 * t)
        val e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
        val c = sin(rad(m)) * (1.914602 - t * (0.004817 + 0.000014 * t)) + sin(rad(2*m)) * (0.019993 - 0.000101*t) + sin(rad(3*m))*0.000289
        val trueLong = l0 + c
        val omega = 125.04 - 1934.136 * t
        val lambda = trueLong - 0.00569 - 0.00478 * sin(rad(omega))
        val seconds = 21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))
        val obliq0 = 23.0 + (26.0 + seconds / 60.0) / 60.0
        val obliq = obliq0 + 0.00256 * cos(rad(omega))
        val decl = asin(sin(rad(obliq)) * sin(rad(lambda)))
        val y = tan(rad(obliq) / 2).pow(2)
        val eq = 4 * Math.toDegrees(y * sin(2*rad(l0)) - 2*e*sin(rad(m)) + 4*e*y*sin(rad(m))*cos(2*rad(l0)) - 0.5*y*y*sin(4*rad(l0)) - 1.25*e*e*sin(2*rad(m)))
        val tz = 2.0 // Africa/Tripoli is UTC+2; no daylight-saving adjustment currently.
        val noon = 12.0 + tz - LON / 15.0 - eq / 60.0
        fun hourAngle(altitudeDeg: Double): Double {
            val cosH = (sin(rad(altitudeDeg)) - sin(rad(LAT))*sin(decl)) / (cos(rad(LAT))*cos(decl))
            return Math.toDegrees(acos(cosH.coerceIn(-1.0, 1.0))) / 15.0
        }
        val sunrise = noon - hourAngle(-0.833)
        val sunset = noon + hourAngle(-0.833)
        val fajr = noon - hourAngle(-18.0)
        val isha = noon + hourAngle(-17.5)
        val asrAltitude = Math.toDegrees(atan(1.0 / (1.0 + tan(abs(rad(LAT) - decl)))))
        val asr = noon + hourAngle(asrAltitude)
        return listOf(
            make("الفجر", fajr), make("الشروق", sunrise), make("الظهر", noon + 2.0/60.0),
            make("العصر", asr), make("المغرب", sunset), make("العشاء", isha)
        )
    }

    fun zoneId(): ZoneId = zone
    private fun make(name: String, decimal: Double): PrayerTime {
        var total = (decimal * 60.0).roundToInt()
        total = ((total % 1440) + 1440) % 1440
        val h = total / 60; val m = total % 60
        return PrayerTime(name, "%02d:%02d".format(h, m), h, m)
    }
    private fun rad(v: Double) = Math.toRadians(v)
    private fun norm(v: Double): Double = ((v % 360.0) + 360.0) % 360.0
}
