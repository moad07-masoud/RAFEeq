package com.rafeeq.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Deep = Color(0xFF07110E)
private val Panel = Color(0xFF12211B)
private val Green = Color(0xFF1E6B4C)
private val Gold = Color(0xFFD8B96D)
private val Cream = Color(0xFFF4F0E4)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        if (BuildVersion.atLeast33() && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
        }
        PrayerAlarm.scheduleNext(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Deep, surface = Panel)) { RafeeqScreen(::speakArabic) } }
    }

    private fun speakArabic(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "rafeeq-voice") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

private object BuildVersion { fun atLeast33() = android.os.Build.VERSION.SDK_INT >= 33 }

private data class Ayah(val text: String, val surah: String, val number: String, val meaning: String)
private val ayat = listOf(
    Ayah("يَا أَيُّهَا الَّذِينَ آمَنُوا اسْتَعِينُوا بِالصَّبْرِ وَالصَّلَاةِ ۚ إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", "البقرة", "153", "استعن بالصبر والصلاة، فالله مع الصابرين."),
    Ayah("إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ", "العنكبوت", "45", "الصلاة تعين المؤمن على ترك المعاصي والمنكرات."),
    Ayah("وَأَقِمِ الصَّلَاةَ لِذِكْرِي", "طه", "14", "أقم الصلاة لتذكر الله وتعبده."),
    Ayah("فَإِذَا فَرَغْتَ فَانصَبْ ۝ وَإِلَىٰ رَبِّكَ فَارْغَب", "الشرح", "7–8", "إذا فرغت من عملك فاجتهد في العبادة، وتوجه إلى ربك.")
)

@Composable
private fun RafeeqScreen(speak: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var selected by remember { mutableStateOf("الرئيسية") }
    var response by remember { mutableStateOf("حان وقت الصلاة؟ رفيق يذكّرك برفق، ويعينك على عدم التأجيل.") }
    val prefs = remember { context.getSharedPreferences("rafeeq", 0) }
    val dateKey = LocalDate.now(PrayerTimes.zoneId()).toString()
    var done by remember(dateKey) { mutableStateOf(prefs.getStringSet("done_$dateKey", emptySet())?.toSet() ?: emptySet()) }
    val savedDate = prefs.getString("done_date", "")
    if (savedDate != dateKey) { done = emptySet(); prefs.edit().putString("done_date", dateKey).apply() }
    val prayerTimes = remember { PrayerTimes.today() }
    val now = LocalTime.now(PrayerTimes.zoneId())
    val nextPrayer = prayerTimes.firstOrNull { it.name != "الشروق" && LocalTime.of(it.hour, it.minute).isAfter(now) }
        ?: prayerTimes.first { it.name == "الفجر" }
    val nextLabel = if (LocalTime.of(nextPrayer.hour, nextPrayer.minute).isAfter(now)) nextPrayer.name else "الفجر غداً"
    val ayah = remember(dateKey) { ayat[(LocalDate.parse(dateKey).toEpochDay() % ayat.size).toInt()] }
    val speechIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-LY")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث مع رفيق")
        }
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (spoken != null) {
            val normalized = spoken.lowercase()
            response = when {
                normalized.contains("صليت") || normalized.contains("صلي") -> "تقبّل الله منك، وثبّتك على الصلاة."
                normalized.contains("شوي") || normalized.contains("بعدين") || normalized.contains("بعد") -> "لا تؤجل الصلاة بلا حاجة. قم الآن، فالمحافظة على الصلاة في وقتها من أعظم الأعمال."
                else -> "سمعتك تقول: $spoken. تذكّر أن الصلاة صلة بينك وبين الله. هل ستقوم الآن؟"
            }
            speak(response)
        }
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            try { voiceLauncher.launch(speechIntent) } catch (_: Exception) { response = "ميزة التعرف على الصوت تحتاج خدمة صوت مثبتة على هاتفك." }
        } else response = "اسمح لرفيق باستخدام الميكروفون حتى يسمع ردك الصوتي."
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Deep) {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("رَفِيق", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text("رفيقك إلى الصلاة", color = Cream.copy(alpha = .7f), fontSize = 12.sp)
                    }
                    Text("✦", color = Gold, fontSize = 28.sp)
                }
                LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("طرابلس، ليبيا", color = Cream.copy(alpha = .75f), fontSize = 14.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("الصلاة القادمة", color = Gold, fontSize = 14.sp)
                                Text(nextLabel, color = Cream, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                                Text("${nextPrayer.time}", color = Gold, fontSize = 23.sp)
                                Text("المواقيت محسوبة محلياً — راجع الضبط المحلي", color = Cream.copy(alpha = .55f), fontSize = 11.sp)
                            }
                        }
                    }
                    item {
                        Text("مواقيت الصلاة", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                prayerTimes.filter { it.name != "الشروق" }.forEach { p ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                        Text(p.name, color = Cream, fontSize = 16.sp)
                                        Text(p.time, color = Gold, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    if (p.name != "العشاء") HorizontalDivider(color = Color.White.copy(alpha = .08f))
                                }
                            }
                        }
                    }
                    item {
                        Text("آية اليوم", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF18291F)), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                Text(ayah.text, color = Cream, fontSize = 21.sp, textAlign = TextAlign.Center, lineHeight = 36.sp, fontWeight = FontWeight.Medium)
                                Spacer(Modifier.height(12.dp))
                                Text("سورة ${ayah.surah} • الآية ${ayah.number}", color = Gold, modifier = Modifier.align(Alignment.CenterHorizontally))
                                Spacer(Modifier.height(8.dp))
                                Text(ayah.meaning, color = Cream.copy(alpha = .75f), fontSize = 13.sp, textAlign = TextAlign.Center)
                            }
                        }
                    }
                    item {
                        Text("مساعد رفيق الصوتي", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Mic, contentDescription = "ميكروفون", tint = Gold, modifier = Modifier.size(34.dp))
                                Text(response, color = Cream, textAlign = TextAlign.Center, fontSize = 14.sp)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                        try { voiceLauncher.launch(speechIntent) } catch (_: Exception) { response = "ميزة التعرف على الصوت تحتاج خدمة صوت مثبتة على هاتفك." }
                                    } else audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }, colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                                    Icon(Icons.Default.Mic, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("تحدث مع رفيق")
                                }
                                TextButton(onClick = { response = "لا تؤجل الصلاة بلا حاجة. قم الآن، فالصلاة في وقتها خير لك."; speak(response) }) { Text("ذكّرني بالصلاة", color = Gold) }
                            }
                        }
                    }
                    item {
                        Text("متابعة صلواتي اليوم", color = Cream, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(14.dp)) {
                                listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء").forEach { prayer ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = done.contains(prayer), onCheckedChange = { checked ->
                                            done = if (checked) done + prayer else done - prayer
                                            prefs.edit().putStringSet("done_$dateKey", done).apply()
                                        }, colors = CheckboxDefaults.colors(checkedColor = Green, uncheckedColor = Gold))
                                        Text(prayer, color = Cream)
                                    }
                                }
                            }
                        }
                    }
                    item {
                        Text("لا تؤجل لقاءك مع الله.", color = Gold, modifier = Modifier.fillMaxWidth().padding(10.dp), textAlign = TextAlign.Center, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                NavigationBar(containerColor = Color(0xFF0D1914)) {
                    listOf("الرئيسية", "الأذكار", "القبلة", "الإعدادات").forEachIndexed { index, label ->
                        NavigationBarItem(selected = selected == label, onClick = { selected = label; if (label != "الرئيسية") response = when(label) { "الأذكار" -> "قسم الأذكار قيد الإضافة في النسخة القادمة."; "القبلة" -> "سيتم إضافة تحديد اتجاه القبلة بالبوصلة في التحديث القادم."; else -> "الإعدادات: المدينة الافتراضية طرابلس، ليبيا." } }, icon = { Icon(when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.AutoAwesome; 2 -> Icons.Default.Explore; else -> Icons.Default.Settings }, contentDescription = label) }, label = { Text(label, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Gold, selectedTextColor = Gold, unselectedIconColor = Cream.copy(alpha = .55f), unselectedTextColor = Cream.copy(alpha = .55f)))
                    }
                }
            }
        }
    }
}
