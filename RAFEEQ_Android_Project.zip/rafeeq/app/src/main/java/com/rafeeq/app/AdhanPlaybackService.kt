package com.rafeeq.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import java.util.Locale

/** Plays a locally supplied adhan recording. If none is installed, announces prayer time with Arabic TTS. */
class AdhanPlaybackService : Service() {
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prayer = intent?.getStringExtra("prayer_name") ?: "الصلاة"
        val channelId = "rafeeq_adhan_playback"
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel(channelId, "الأذان", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان وقت صلاة $prayer")
            .setContentText("رفيق يذكّرك بالصلاة")
            .setOngoing(true)
            .build()
        startForeground(8101, notification)

        val audioId = resources.getIdentifier("adhan", "raw", packageName)
        if (audioId != 0) {
            try {
                player?.release()
                player = MediaPlayer.create(this, audioId)?.apply {
                    setOnCompletionListener { stopSelf() }
                    setOnErrorListener { _, _, _ -> stopSelf(); true }
                    start()
                }
                if (player == null) announceFallback(prayer)
            } catch (_: Exception) { announceFallback(prayer) }
        } else {
            announceFallback(prayer)
        }
        return START_NOT_STICKY
    }

    private fun announceFallback(prayer: String) {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ar")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onDone(utteranceId: String?) { stopSelf() }
                    override fun onError(utteranceId: String?) { stopSelf() }
                })
                tts?.speak("حان الآن وقت صلاة $prayer. حي على الصلاة.", TextToSpeech.QUEUE_FLUSH, null, "rafeeq-adhan-fallback")
            } else stopSelf()
        }
    }

    override fun onDestroy() {
        player?.stop(); player?.release(); player = null
        tts?.stop(); tts?.shutdown(); tts = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
